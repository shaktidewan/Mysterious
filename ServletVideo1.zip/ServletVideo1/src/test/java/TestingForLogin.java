/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import studyviral.in.LoginDAO;
import studyviral.in.RegisterBean;

/**
 *
 * @author 97798
 */
public class TestingForLogin {
    
    private RegisterBean bn;
    LoginDAO l;
    
    public TestingForLogin() {
        
    bn = new RegisterBean();
    bn.setEmail("np03a180164@gmail.com");
    bn.setPword("admin");
    bn.setRole("Admin");
    }
    
    @Test
    public void test_blank(){
    
        bn.setEmail("");
        bn.setPword("");
        bn.setRole("");
        
        String msg = l.authenticateUser(bn);
        assertTrue(true);
    
    }
    
    
    @Test
    public void test_length(){
    bn.setEmail("np03a180164@gmail.com");
    bn.setPword("admin");
    
    int i = "admin".length();
    if(i>0){
        assertTrue(true);
    }else{
        assertTrue(false);
    }
    }
    
    
    
    
    
    
}
