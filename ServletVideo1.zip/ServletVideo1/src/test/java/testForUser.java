/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import studyviral.in.User;

/**
 *
 * @author 97798
 */
public class testForUser {
    private User user;
    
    public testForUser() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
     user = new User(1, "Ram", "Lama", "ram@gmail.com", "ram123", "ac123", 1, "User", "What is your crush name", "Sita", "Unblock");

    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    
    @Test
    public void Get_id_test(){
    int id = user.getId();
    assertTrue(id == 1);
    }
    
     @Test
    public void Get_email_test(){
    String email = user.getEmail();
    assertEquals("ram@gmail.com",email);
    }
    
    @Test
    public void Get_answer_test(){
    String ans = user.getAns();
    assertEquals("geeta",ans);
    }
}
