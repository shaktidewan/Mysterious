/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.herald.models.serlvet.User;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


/**
 *
 * @author 97798
 */
public class testForFogotPassword {
    User user;
    public testForFogotPassword() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        
    user = new User(1, "Ram", "Lama", "ram@gmail.com", "ram123", "ac123", 1, "User", "What is your crush name", "Sita", "Unblock");

    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    @Test
    public void test_checking_email(){
    String email = user.getEmail();
    assertEquals("ram@gmail.com",email);
    }
    
    @Test
    public void test_checking_ques(){
    String ques = user.getQues();
    assertEquals("What is your crush name",ques);
    }
    
     @Test
    public void test_checking_ans(){
    String ans = user.getAns();
    assertTrue(ans == "981012");
    }
    
}
