/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.herald.models.serlvet.RegisterBean;
import com.herald.models.serlvet.RegisterDAO;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


/**
 *
 * @author 97798
 */
public class testForRegister {
    
    private RegisterBean bn;
    RegisterDAO rg;
    
    public testForRegister() {
        
        bn= new RegisterBean();
        bn.setFname("Shakti");
        bn.setLname("Dewan");
        bn.setEmail("shaktiyakhha@gmail.com");
        bn.setPword("shakti");
        bn.setQues("What is your first phone number");
        bn.setAns("9810138470");
    }
    
    @Test
    public void test_blank_register(){
        String name = bn.getFname();
        assertTrue(name == "");
        
    }
    
    
    
    @Test
    public void test_register(){
        String fname= bn.getFname();
        String lname =bn.getLname();
        String email=bn.getEmail();
        String pword=bn.getPword();
        String ques=bn.getQues();
        String ans=bn.getAns();
       
        assertEquals("Shakti",fname);
        assertEquals("Dewan",lname);
        assertEquals("shaktiyakhha@gmail.com",email);
        assertEquals("shakti",pword);
        assertEquals("What is your first phone number",ques);
        assertEquals("9810138470",ans);
        
    }
    
    
}
