/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.herald.models.serlvet.RegisterBean;
import com.herald.models.serlvet.UserHistory;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author 97798
 */
public class testinghistory {
    private RegisterBean bn;
    UserHistory uh;
    
    public testinghistory() {
        bn= new RegisterBean();
        bn.setFname("Shakti");
        bn.setLname("Dewan");
        bn.setEmail("shaktiyakhha@gmail.com");
        bn.setPword("shakti");
        bn.setQues("What is your first phone number");
        bn.setAns("9810138470");
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        uh = new UserHistory(bn,"user is registered","user is registered at");
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    
    @Test
    public void test_email(){
    String em = bn.getEmail();
    assertEquals(em,"shaktiyakhha@gmail.com");
    }
    @Test
    public void testForhisotry(){
    String act = uh.getAction();
    assertEquals(act,"user is not registered");
    
    }
}
