
package com.herald.models.serlvet;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

/**
 *
 * @author Toyota
 */
class UserHistory {
     private int id;
    private RegisterBean user;
    private String action;
    private String detail;
    private Timestamp dateAndTime;

    public UserHistory(int id, RegisterBean user, String action, String detail, Timestamp dateAndTime) {
        this.id = id;
        this.user = user;
        this.action = action;
        this.detail = detail;
        this.dateAndTime = dateAndTime;
    }



    
    public UserHistory(RegisterBean user, String action, String detail) {
        this.user = user;
        this.action = action;
        this.detail = detail;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public RegisterBean getUser() {
        return user;
    }
    
    public void setUser(RegisterBean user) {
        this.user = user;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getDateAndTime() {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd, hh:mm:ss a");
        return formatter.format(dateAndTime);
    }

    public void setDateAndTime(Timestamp dateAndTime) {
        this.dateAndTime = dateAndTime;
    }
    
    @Override
    public String toString() {
        return "User History(" + "id=" + id + ", user=" + user.getEmail() + ", action=" + action + ", detail=" + detail + ", date and time=" + dateAndTime + '}';
    }
    

}
