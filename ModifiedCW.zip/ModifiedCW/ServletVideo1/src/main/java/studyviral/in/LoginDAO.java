/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studyviral.in;

import connection.singleton.MyConnection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author 97798
 */
public class LoginDAO {
    
//    String sql ="select * from usertable where email=? and pword=? and role=?";
    String url="jdbc:mysql://localhost:3306/email_validation";
    String username="root";
    String password="";
    
//    public boolean check(String email,String pword){
//        try{
//             Class.forName("com.mysql.jdbc.Driver");
//            Connection con= DriverManager.getConnection(url, username, password);
//            PreparedStatement st=con.prepareStatement(sql);
//            st.setString(1, email);
//            st.setString(2, pword);
//            
//            
//            ResultSet rs= st.executeQuery();
//            if(rs.next())
//            {
//                
//                return true;
//            }
//        
//        }catch(Exception e){
//        e.printStackTrace();
//        }
//        
//    
//    return false;
//    }
    
public String authenticateUser(RegisterBean bean)
{
String email = bean.getEmail();
String pword = bean.getPword();

    Connection con = null;
    Statement statement = null;
    ResultSet resultSet = null;
 
    String userNameDB = "";
    String passwordDB = "";
    String roleDB = "";
    String typeDB="";
    
    try
    {
        con = MyConnection.getConnection();
        statement = con.createStatement();
        resultSet = statement.executeQuery("select email,pword,role,type from usertable");
 
        while(resultSet.next())
        {
            userNameDB = resultSet.getString("email");
            passwordDB = resultSet.getString("pword");
            roleDB = resultSet.getString("role");
            typeDB = resultSet.getString("type");
 
            if(email.equals(userNameDB) && pword.equals(passwordDB) && roleDB.equals("Admin")&& typeDB.equals("Unblock"))
            return "Admin_Role";
            
            else if(email.equals(userNameDB) && pword.equals(passwordDB) && roleDB.equals("User") && typeDB.equals("Unblock"))
            return "User_Role";
        }
    }
    catch(SQLException e)
    {
        e.printStackTrace();
    }
    return "Invalid user credentials";
}
}
    

