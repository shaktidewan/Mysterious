/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.herald.models.serlvet;

/**
 *
 * @author 97798
 */
public class User {
    int id;
    String fname;
    String lname;
    String email;
    String pword;
    String hash;
    int active;
    String role;
    String ques;
    String ans;  
    String type;

    public User() {
    }

    public User(int id, String fname, String lname, String email, String pword, String hash, int active, String role, String ques, String ans, String type) {
        this.id = id;
        this.fname = fname;
        this.lname = lname;
        this.email = email;
        this.pword = pword;
        this.hash = hash;
        this.active = active;
        this.role = role;
        this.ques = ques;
        this.ans = ans;
        this.type=type;
    }

    public User(String fname, String lname, String email, String pword, String hash, int active, String role, String ques, String ans, String type) {
        this.fname = fname;
        this.lname = lname;
        this.email = email;
        this.pword = pword;
        this.hash = hash;
        this.active = active;
        this.role = role;
        this.ques = ques;
        this.ans = ans;
        this.type=type;
    }
    
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPword() {
        return pword;
    }

    public void setPword(String pword) {
        this.pword = pword;
    }

    public String getHash() {
        return hash;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }

    public int getActive() {
        return active;
    }

    public void setActive(int active) {
        this.active = active;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getQues() {
        return ques;
    }

    public void setQues(String ques) {
        this.ques = ques;
    }

    public String getAns() {
        return ans;
    }

    public void setAns(String ans) {
        this.ans = ans;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
    
    
    
}

